# Basic Flipkart Front Page Clone
- This is a Simple Flipkart Front Page Project Using HTML5, CSS3,Javascript
